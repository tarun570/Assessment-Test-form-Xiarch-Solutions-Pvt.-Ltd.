import os
from pathlib import Path

import pytest

from knowledge_agent import read_knowledge, execute_action


def test_read_knowledge_file_exists(tmp_path):
    data = {"test": "value"}
    file_path = tmp_path / "internal_knowledge.json"
    file_path.write_text('{"test": "value"}', encoding="utf-8")

    current_dir = Path(__file__).resolve().parent.parent
    os.chdir(str(tmp_path))

    try:
        assert read_knowledge(str(file_path.name)) == data
    finally:
        os.chdir(str(current_dir))


def test_execute_action_writes_audit(tmp_path):
    current_dir = Path(__file__).resolve().parent.parent
    os.chdir(str(tmp_path))

    try:
        result = execute_action("log_action", "details")
        assert result["status"] == "executed"
        assert Path("knowledge_audit.json").resolve() == (Path(os.getcwd()) / "knowledge_audit.json").resolve()
        assert Path("knowledge_audit.json").exists()
    finally:
        os.chdir(str(current_dir))
