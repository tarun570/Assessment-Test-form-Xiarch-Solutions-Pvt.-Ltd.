import os
from pathlib import Path

import pytest

import secure_coding_agent as sca


def test_get_language_from_path():
    assert sca.get_language_from_path("file.py") == "python"
    assert sca.get_language_from_path("file.js") == "javascript"
    assert sca.get_language_from_path("file.php") == "php"
    assert sca.get_language_from_path("file.txt") == "unknown"


def test_read_source_and_save_patch(tmp_path):
    source_path = tmp_path / "vulnerable.py"
    source_path.write_text("print('hello')\n")

    assert sca.read_source(str(source_path)) == "print('hello')\n"

    patched_path = sca.save_patch(str(source_path), "print('patched')\n")
    assert Path(patched_path).exists()
    assert Path(patched_path).read_text() == "print('patched')\n"


def test_secure_agent_errors_on_missing_file():
    with pytest.raises(FileNotFoundError):
        sca.run_secure_agent("does_not_exist.py")
