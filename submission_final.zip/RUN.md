# Run and Cleanup Guide

This file explains how to run the three agents, run tests, and suggests files/folders that are safe to remove from the repository if you want a smaller submission package.

## Prerequisites
- Python 3.8+ (3.12 recommended)
- Create and activate a virtual environment (recommended)
- Install dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Set your OpenAI API key (either in `.env` or environment):

```powershell
$env:OPENAI_API_KEY="sk-..."
# or create a .env file with OPENAI_API_KEY=sk-...
```

## Run the agents

- Option 1 — Autonomous Research Agent

```powershell
python agent.py "impact of quantum computing on cryptography"
# add --pdf to also export PDF
python agent.py "topic" --pdf
```

- Option 2 — Secure Coding Assistant

```powershell
python secure_coding_agent.py vulnerable.py
# provide path to a real source file to analyze
```

- Option 3 — Internal Knowledge Execution Agent

```powershell
python knowledge_agent.py "What internal project information is available?"
```

## Test & validation

Run unit tests:

```powershell
python -m pytest -q
```

Quick syntax check:

```powershell
python -m py_compile agent.py tools.py secure_coding_agent.py knowledge_agent.py
```

## Files/folders that are safe to remove (optional)

These are commonly not required for submission and can be removed to reduce package size:

- `venv/` or any local virtual environment folder (do NOT remove if you rely on it locally)
- `.pytest_cache/` and `__pycache__/` directories
- `submission_option1.zip` (old packaged artifact)
- `demo.ps1`, `demo.sh` (optional demo scripts)
- `estimate_call_cost.py`, `check_cost.py` (developer utilities; keep if you want cost tools)

To delete them (PowerShell):

```powershell
Remove-Item -Recurse -Force .\venv
Remove-Item -Recurse -Force .\.pytest_cache
Remove-Item -Recurse -Force .\__pycache__
Remove-Item -Force .\submission_option1.zip
Remove-Item -Force .\demo.ps1
Remove-Item -Force .\demo.sh
```

Or (bash):

```bash
rm -rf venv/ .pytest_cache/ __pycache__/ submission_option1.zip demo.ps1 demo.sh
```

Note: Do not delete source files like `agent.py`, `tools.py`, `secure_coding_agent.py`, `knowledge_agent.py`, `tests/`, or `README.md` unless you intentionally want to remove that feature.

## Clean package suggestion

To create a submission ZIP containing only the essential files:

```powershell
# from repo root
Compress-Archive -Path agent.py,tools.py,secure_coding_agent.py,knowledge_agent.py,tests,README.md,requirements.txt -DestinationPath submission_final.zip
```

Or (bash):

```bash
zip -r submission_final.zip agent.py tools.py secure_coding_agent.py knowledge_agent.py tests README.md requirements.txt
```

---

If you want, I can remove the optional files for you or create the submission ZIP now.