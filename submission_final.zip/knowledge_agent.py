import argparse
import json
import os
import sys
from datetime import datetime, timezone
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

MODEL = "gpt-4o"
MAX_TURNS = 8

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

SYSTEM_PROMPT = """You are an autonomous internal knowledge execution agent.

Your job is to answer user queries using only the provided internal knowledge
sources. You must reason over the data, select the appropriate action, execute
it, and explain why you chose that action.
"""

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "read_knowledge",
            "description": "Read available internal knowledge from JSON files.",
            "parameters": {
                "type": "object",
                "properties": {
                    "source": {"type": "string"}
                },
                "required": ["source"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "execute_action",
            "description": "Execute a selected action based on the internal knowledge.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {"type": "string"},
                    "details": {"type": "string"}
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "finalize_response",
            "description": "Return the final answer, reasoning, and executed action summary.",
            "parameters": {
                "type": "object",
                "properties": {
                    "response": {"type": "string"},
                    "reasoning": {"type": "string"},
                    "action_executed": {"type": "string"}
                },
                "required": ["response", "reasoning", "action_executed"],
            },
        },
    },
]


def read_knowledge(source: str) -> dict:
    source = source.strip()
    if source.lower() == "all":
        knowledge = {}
        directory = os.path.dirname(__file__)
        for filename in os.listdir(directory):
            if filename.endswith(".json"):
                path = os.path.join(directory, filename)
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        knowledge[filename] = json.load(f)
                except Exception:
                    knowledge[filename] = {"error": "Failed to load"}
        return knowledge

    if os.path.isabs(source):
        path = source
    else:
        cwd_path = os.path.join(os.getcwd(), source)
        repo_path = os.path.join(os.path.dirname(__file__), source)
        path = cwd_path if os.path.exists(cwd_path) else repo_path

    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    # fallback aliases for common knowledge source names
    aliases = [
        "internal_project_data.json",
        "internal_knowledge.json",
        "knowledge_data.json",
        "project_data.json",
    ]
    for alias in aliases:
        alias_path = (os.path.join(os.getcwd(), alias)
                      if os.path.exists(os.path.join(os.getcwd(), alias))
                      else os.path.join(os.path.dirname(__file__), alias))
        if os.path.exists(alias_path):
            with open(alias_path, "r", encoding="utf-8") as f:
                return {
                    "loaded_from": alias,
                    "content": json.load(f),
                }

    return {"error": f"Source not found: {source}"}


def execute_action(action: str, details: str) -> dict:
    audit_entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "action": action,
        "details": details,
    }
    log_path = os.path.join(os.getcwd(), "knowledge_audit.json")
    audit = []
    if os.path.exists(log_path):
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                audit = json.load(f)
        except (json.JSONDecodeError, ValueError):
            audit = []
    audit.append(audit_entry)
    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(audit, f, indent=2)
    return {"status": "executed", "audit_entry": audit_entry}


def run_knowledge_agent(query: str) -> dict:
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"User query: {query}"},
    ]

    for turn in range(MAX_TURNS):
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=TOOLS_SCHEMA,
            tool_choice="auto",
        )
        msg = response.choices[0].message
        messages.append(msg.model_dump(exclude_none=True))

        if not msg.tool_calls:
            messages.append({
                "role": "user",
                "content": "Please continue reasoning over the knowledge sources and decide which action to execute.",
            })
            continue

        for call in msg.tool_calls:
            name = call.function.name
            args = json.loads(call.function.arguments or "{}")
            if name == "read_knowledge":
                data = read_knowledge(args["source"])
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps(data)[:15000],
                })
            elif name == "execute_action":
                result = execute_action(args["action"], args.get("details", ""))
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps(result),
                })
            elif name == "finalize_response":
                return {
                    "response": args["response"],
                    "reasoning": args["reasoning"],
                    "action_executed": args["action_executed"],
                }
            else:
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps({"error": "Unknown tool."}),
                })

    raise RuntimeError("Knowledge agent did not finalize within the turn limit.")


def main():
    parser = argparse.ArgumentParser(description="Autonomous Knowledge Execution Agent")
    parser.add_argument("query", type=str, help="User query to answer from internal knowledge")
    args = parser.parse_args()

    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("Set OPENAI_API_KEY in your environment before running.")

    result = run_knowledge_agent(args.query)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
