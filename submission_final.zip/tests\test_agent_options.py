import os

import pytest

from agent import run_agent
from secure_coding_agent import get_language_from_path


def test_get_language_from_path():
    assert get_language_from_path("example.py") == "python"
    assert get_language_from_path("example.js") == "javascript"
    assert get_language_from_path("example.php") == "php"
    assert get_language_from_path("example.txt") == "unknown"


def test_agent_run_requires_openai_key(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(SystemExit):
        run_agent("test query")
