import argparse
import json
import os
import re
import sys
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

MODEL = "gpt-4o"
MAX_TURNS = 8

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

SYSTEM_PROMPT = """You are an autonomous secure coding assistant.

Your task is to inspect a single source code file, identify any security
vulnerabilities, explain them, and generate a patched version of the code.

Do not use hard-coded responses. Work entirely from the input file and your
own reasoning. Preserve the original application behavior where possible.
"""

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "read_source",
            "description": "Read the vulnerable source file and return its contents.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"}
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "analyze_code",
            "description": "Analyze the source code and identify vulnerabilities.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"}
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_patch",
            "description": "Generate a secure patched version of the source code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "analysis": {"type": "string"},
                    "patched_code": {"type": "string"}
                },
                "required": ["path", "patched_code"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "finalize_fix",
            "description": "Return the final vulnerability summary and the patched code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "vulnerability_description": {"type": "string"},
                    "patched_code": {"type": "string"},
                    "patch_file": {"type": "string"}
                },
                "required": ["vulnerability_description", "patched_code", "patch_file"],
            },
        },
    },
]


def get_language_from_path(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".py":
        return "python"
    if ext in (".js", ".jsx", ".ts", ".tsx"):
        return "javascript"
    if ext in (".php",):
        return "php"
    return "unknown"


def read_source(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def compile_python_code(code: str) -> bool:
    try:
        compile(code, "patched_code", "exec")
        return True
    except Exception:
        return False


def save_patch(path: str, patched_code: str) -> str:
    directory, filename = os.path.split(path)
    name, ext = os.path.splitext(filename)
    patched_name = f"{name}_patched{ext}"
    patched_path = os.path.join(directory, patched_name)
    with open(patched_path, "w", encoding="utf-8") as f:
        f.write(patched_code)
    return patched_path


def run_secure_agent(path: str) -> dict:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Source file not found: {path}")

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Securely analyze and patch the file at {path}."},
    ]

    for turn in range(MAX_TURNS):
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=TOOLS_SCHEMA,
            tool_choice="auto",
        )
        msg = response.choices[0].message
        messages.append(msg.model_dump(exclude_none=True))

        if not msg.tool_calls:
            messages.append({
                "role": "user",
                "content": "Please continue and use the available tools to analyze and patch the code.",
            })
            continue

        for call in msg.tool_calls:
            name = call.function.name
            args = json.loads(call.function.arguments or "{}")
            if name == "read_source":
                content = read_source(args["path"])
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps({"source_code": content}),
                })
            elif name == "analyze_code":
                content = read_source(args["path"])
                language = get_language_from_path(args["path"])
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps({
                        "language": language,
                        "source_code": content,
                        "analysis": "Review the code for security issues and respond with specific vulnerabilities."
                    }),
                })
            elif name == "generate_patch":
                patched = args.get("patched_code", "")
                if not patched:
                    patched = read_source(args["path"])
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps({"patched_code": patched}),
                })
            elif name == "finalize_fix":
                patch_file = save_patch(args["patch_file"] if args.get("patch_file") else path, args["patched_code"])
                if get_language_from_path(path) == "python" and not compile_python_code(args["patched_code"]):
                    raise RuntimeError("Patched Python code failed syntax validation.")
                return {
                    "vulnerability_description": args["vulnerability_description"],
                    "patched_code": args["patched_code"],
                    "patch_file": patch_file,
                }
            else:
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps({"error": "Unknown tool."}),
                })

    raise RuntimeError("Secure coding agent did not finalize within the turn limit.")


def main():
    parser = argparse.ArgumentParser(description="Secure Coding Assistant")
    parser.add_argument("path", type=str, help="Path to the vulnerable source file")
    args = parser.parse_args()

    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("Set OPENAI_API_KEY in your environment before running.")

    result = run_secure_agent(args.path)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
